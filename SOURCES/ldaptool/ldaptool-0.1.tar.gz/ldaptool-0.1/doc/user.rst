User Documentation
==================

The user documentation is devoted in explaining how to use ldaptool, how to
invoke it on the command line and how to configure ldaptool.

.. toctree::
    :maxdepth: 2
    
    user-usage
    user-config

